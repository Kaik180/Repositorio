document.addEventListener('DOMContentLoaded', () => {

   
    const formLogin = document.getElementById('formLogin');
    
    if (formLogin) {
        formLogin.addEventListener('submit', (e) => {
            e.preventDefault();

            const usuario = document.getElementById('loginEmail').value;
            const clave = document.getElementById('loginPassword').value;

         
            if (usuario !== "" && clave !== "") {
                alert("Accediendo a tu tablero de Trello...");
                window.location.href = 'trello.html';
            } else {
                alert("Debes rellenar todos los campos.");
            }
        });
    }

   
    const btnAnadir = document.getElementById('btnAnadir');
    const inputTarea = document.getElementById('inputTarea');
    
   
    const listaPendientes = document.querySelector('#pendientes .lista-tareas');
    const listaTerminadas = document.querySelector('#terminadas .lista-tareas');

    if (btnAnadir) {
        btnAnadir.addEventListener('click', () => {
            const texto = inputTarea.value;

            if (texto.trim() === "") {
                alert("Escribe una tarea para el tablero.");
                return;
            }

            
            const nuevaTarea = document.createElement('div');
            nuevaTarea.classList.add('tarea');
            
            nuevaTarea.innerHTML = `
                <p style="margin: 0;">${texto}</p>
                <small style="color: #8899a6;">Click para avanzar →</small>
            `;

           
            nuevaTarea.addEventListener('click', () => {
               
                if (nuevaTarea.closest('#pendientes')) {
                    listaTerminadas.appendChild(nuevaTarea);
                    nuevaTarea.querySelector('small').textContent = "Click para eliminar 🗑️";
                } 
                
                else {
                    nuevaTarea.remove();
                }
            });

            
            listaPendientes.appendChild(nuevaTarea);

            
            inputTarea.value = "";
        });
    }
});