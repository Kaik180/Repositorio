document.addEventListener('DOMContentLoaded', () => {

    
    const formLogin = document.getElementById('formLogin');
    
    if (formLogin) {
        formLogin.addEventListener('submit', (e) => {
            e.preventDefault(); 

            const email = document.getElementById('loginEmail').value;
            const pass = document.getElementById('loginPassword').value;

      
            if (email !== "" && pass !== "") {
                alert("Sesión iniciada correctamente");
                window.location.href = 'app.html'; 
            } else {
                alert("Por favor, rellena todos los campos");
            }
        });
    }

    
    const boton = document.getElementById('btnEnviar');
    const entradaTexto = document.getElementById('textoTarea');
    const muro = document.getElementById('muroMensajes');

    if (boton) {
        boton.addEventListener('click', () => {
            const mensaje = entradaTexto.value;

            if (mensaje.trim() === "") {
                alert("Por favor, escribe algo.");
                return;
            }

           
            const nuevoElemento = document.createElement('div');
            nuevoElemento.classList.add('mensaje-post');
            
          
            nuevoElemento.innerHTML = `
                <p>${mensaje}</p>
                <small>Posteado justo ahora</small>
            `;

        
            muro.prepend(nuevoElemento);

           
            entradaTexto.value = "";
        });
    }
});